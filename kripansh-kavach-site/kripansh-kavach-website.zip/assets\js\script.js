// Bootstrap modal product prefill
const quoteModal = document.getElementById('quoteModal');
if (quoteModal) {
  quoteModal.addEventListener('show.bs.modal', event => {
    const button = event.relatedTarget;
    const product = button?.getAttribute('data-product') || '';
    document.getElementById('productInput').value = product;
  });
}

// Basic client-side form validation
(function () {
  'use strict';
  const forms = document.querySelectorAll('.needs-validation');
  Array.from(forms).forEach(form => {
    form.addEventListener('submit', event => {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    }, false);
  });
})();
